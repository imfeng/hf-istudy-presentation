<?php

$pdo = Database::connect();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                
$nRows = $pdo->query('select count(*) from hwiic')->fetchColumn(); 
echo $nRows;


?>