<?php
class Newsletter
{
    private static $email;
    private static $rows;
    private static $datetime = null;

    private static $valid = true;

    public function __construct() {
        die('Init function is not allowed');
    }
    public static function register($rows) {
        $status = 'ERROR';
        $message = 'ERROR';
        if (!empty($_POST)) {
            self::$email    = $_POST['email'];
            self::$datetime = date('Y-m-d H:i:s');
            foreach ($rows as $key => $value) {
                if(empty($rows[$key])){
                    $rows[$key] = 'NULL';
                }
            }
            self::$rows     = $rows;

            if (empty(self::$rows['name'])) {
                $status  = "error";
                $message = "請檢查是否有疏漏資訊 @_@a";
                self::$valid = false;
            }else{}
            if(empty(self::$rows['email'])){
                $status  = "error";
                $message = "請填寫Email！";
                self::$valid = false;
            }else if (!filter_var(self::$email, FILTER_VALIDATE_EMAIL)) {
                $status  = "error";
                $message = "請填寫正確Email！";
                self::$valid = false;
            }

            if (self::$valid) {
                $pdo = Database::connect();
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                /*$existingSignup = $pdo->prepare("SELECT COUNT(*) FROM hwiic WHERE email='$email'");
                $existingSignup->execute();
                $data_exists = ($existingSignup->fetchColumn() > 0) ? true : false;
*/
                if (1) {
                    $sql = "INSERT INTO hwiic (signups_id, name, class, phone, fromwhere, talk, email, s_ip, s_date) VALUES (:id , :name, :class, :phone, :fromwhere, :talk, :email,:s_ip, :s_date)";
                    $q = $pdo->prepare($sql);

                    $q->execute(
                        array(
                            ':id' => NULL,
                            ':name' => self::$rows['name'],
                            ':class' => self::$rows['class'],
                            ':phone' => self::$rows['phone'],
                            ':fromwhere' => self::$rows['fromwhere'],
                            ':talk' => self::$rows['talk'],
                            ':email' => self::$rows['email'],
                            ':s_ip' => self::$rows['s_ip'],
                            ':s_date' => self::$datetime)
                        );

                    if ($q) {
                        $status  = "success";
                        $message = "You have been successfully subscribed";
                    } else {
                        $status  = "error";
                        $message = "123";
                    }
                } else {
                    $status  = "error";
                    $message = "This email is already submit";
                }
            }

            $data = array(
                'status'  => $status,
                'message' => $message
            );

            echo json_encode($data);

            Database::disconnect();
        }
    }
}