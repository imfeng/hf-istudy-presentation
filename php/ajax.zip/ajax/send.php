<?php
require 'inc/Database.class.php';
require 'inc/Newsletter.class.php';
$myip = '';
if(!empty($_SERVER['HTTP_CLIENT_IP'])){
   $myip = $_SERVER['HTTP_CLIENT_IP'];
}else if(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
   $myip = $_SERVER['HTTP_X_FORWARDED_FOR'];
}else{
   $myip= $_SERVER['REMOTE_ADDR'];
}


if (!empty($_POST)) {
    $email = $_POST['signup-email'];
    $rows = array(
    	'name'=>$_POST['name'],
    	'class'=>$_POST['class'],
    	'phone'=>$_POST['phone'],
    	'fromwhere'=>$_POST['fromwhere'],
    	'talk'=>$_POST['talk'],
    	'email'=>$_POST['email'],
        's_ip' =>$myip
    );
    Newsletter::register($rows);
}